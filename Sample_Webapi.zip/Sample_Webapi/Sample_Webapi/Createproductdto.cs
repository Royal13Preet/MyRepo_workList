﻿namespace Sample_Webapi
{
    public class Createproductdto
    {
        public string ProductName { get; set; }
        public int Price { get; set; }
            
    }
}
